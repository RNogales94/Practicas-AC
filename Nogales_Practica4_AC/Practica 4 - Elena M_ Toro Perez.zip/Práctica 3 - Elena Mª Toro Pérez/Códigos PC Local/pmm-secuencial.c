#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 4096

int main(int argc, char **argv){
	int i, j, k, m;
	int filas_columnas;

	int **matrizB;
	int **matrizC;
	int **matrizA;

	if (argc < 2){
		fprintf(stderr,"\nError --> Falta el número de componentes\n");
		return(-1);
	}

//El número de filas y de columnas serán un argumento de entrada
//Como son matrices cuadradas, el número de filas y columnas coincide
//Basta entonces poner un sólo argumento

	filas_columnas = atoi(argv[1]);

	if (filas_columnas > MAX){
		printf("Error --> Tamaño demasiado grande. No superar %d\n\n",MAX);
		return(-1);
	}

//Creamos las matrices
// matrizA = matrizB * matrizC

	matrizB = (int **)malloc(filas_columnas * sizeof(int*));
	matrizC = (int **)malloc(filas_columnas * sizeof(int*));
	matrizA = (int **)malloc(filas_columnas * sizeof(int*));

	for (i=0; i<filas_columnas; i++){
		matrizB[i] = (int *)malloc(filas_columnas * sizeof(int));
		matrizC[i] = (int *)malloc(filas_columnas * sizeof(int));
		matrizA[i] = (int *)malloc(filas_columnas * sizeof(int));
	}

//Liberamos las matrices

	if (matrizC == NULL){
		printf("Error de memoria \n");
		free(matrizC);
		return -1;
	}

	if (matrizC == NULL){
		printf("Error de memoria \n");
		free(matrizC);
		return -1;
	}

//Inicializamos las matrices

	for (j=0; j<filas_columnas; j++){
		for (i=0; i<filas_columnas; i++){
			matrizB[j][i] = j+i;
			matrizC[j][i] = j*i;
		}
	}

	int suma;

	suma = 0;

//Multiplicamos las matrices B y C

	for (i=0; i<filas_columnas; i++){
		for(j=0; j<filas_columnas; j++){
			suma = 0;
			for (k=0; k<filas_columnas; k++){
				suma += (matrizB[i][k]*matrizC[k][j]);
			}
			matrizA[i][j]=suma;
		}
	}

//Imprimimos resultados

	printf ("Componente(0,0) del resultado de la multiplicación de ambas matrices=%d\n",matrizA[0][0]);

	printf ("Componente(N-1,N-1) del resultado de la multiplicación de ambas matrices=%d\n",matrizA[filas_columnas-1][filas_columnas-1]);

}
